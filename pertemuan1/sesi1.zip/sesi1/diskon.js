/*
    #Algoritma hitung diskon
    1. Masukan total belanjaan dari pengguna
    2. jika total belanjaan lebih atau sama dengna 300 ribu, 
        maka lanjut hitung diskon / masuk kelangkah 3. jika tidak maka masuk kelangkah 5
    3. hitung diskon 10% dari total belanjaan
    4. kurangi total belanja dengna jumlah diskon yang dihitung.
    5. tampilkan total belanjaan yang harus di bayarkan oleh pengguna
*/


const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin, 
    output: process.stdout,
});

const totalPayment = function (totalBelanja) {
    let diskon = 0;
    let totalPembayaran = totalBelanja;

    if (totalBelanja >= 300000) {
        diskon = 0.1 * totalBelanja;
        totalPembayaran = totalBelanja - diskon;
    }

    return totalPembayaran;
}

rl.question("Total belanjaan: Rp.", (total) => {
    let payment = totalPayment(total);
    console.log(`Total belanjaan Rp. ${total}`);
    console.log(`yang harus di bayar: Rp.${payment.toLocaleString()}`);
    rl.close();
})