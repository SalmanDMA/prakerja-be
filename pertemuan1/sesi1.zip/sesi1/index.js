/*
    #Algoritma liniar search
    1. Buat perulangan yang berjalan melalui setiap elemen array,
        dimulai dari index 0;
    2. pada setiap ieterasi (perulangan) periksa apakah elemen saat ini sama dengan nilai yang dicari;
    3. jika elemen saat ini dsama dengan elemen yang dicari maka kembalikan
        nilai indexnya
    4. jika tidak ada elemen yang yang cocok setelah selesai perulangan maka kembalikan nilai -1
    5. Selesai
*/

function linierSearch(data, target) {
    for (let index = 0; index < data.length; index++) {
        if (data[index] === target) {
            return index;
        }
    }
    return -1;
}

if (result !== -1) {
    console.log(`data ditemukan pada index ke-${result}`)
} else {
    console.log(`data tidak ditemukan dalam array`);
}